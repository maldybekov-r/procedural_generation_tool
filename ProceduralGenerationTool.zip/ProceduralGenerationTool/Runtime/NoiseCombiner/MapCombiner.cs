public class MapCombiner
{

    private UnityEngine.Renderer _renderer;

    public MapCombiner(UnityEngine.Renderer renderer)
    {
        _renderer = renderer;
    }

    public void Combine(FalloffNoise fallOffNoise, PerlinNoise perlinNoise)
    {
    }
}