public interface IOnHitable
{
    void OnHit();
}